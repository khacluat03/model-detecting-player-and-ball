# football-players-detection > 2025-04-04 5:23am
https://universe.roboflow.com/industrial-university-of-ho-chi-minh-city-inppl/football-players-detection-3zvbc-awjwy

Provided by a Roboflow user
License: CC BY 4.0

